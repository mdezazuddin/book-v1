<?php $page= "contact";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-blue1">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <h1 class="text-white">CONTACT US</h1>
                        <p class="mt-3">
                            <a class="clr-red mr-2 text-white text-decoration-none small" href="index.php">HOME</a> 
                            <span class="text-white small"> / &nbsp; CONTACT US</span>
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2">
            <div class="container-fluid">
                <div class="row">
                    <!-- google-map -->
                    <div class="col-12 p-md-0">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3024.0721376413476!2d-73.73979336718509!3d40.7164284386799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c263d234963e1f%3A0xb8c246c12c49cdc6!2s217-44%2098th%20Ave%2C%20Queens%20Village%2C%20NY%2011429%2C%20USA!5e0!3m2!1sen!2sin!4v1583386875157!5m2!1sen!2sin"
        width="100%" height="480px" frameborder="0" style="margin: 0;" allowfullscreen=""></iframe>
                    </div>
                </div>
            </div>
        </section>


        <!-- section2 -->
        <section class="section2 py-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">CONTACT US</h6>
                        <h2 class="right-reveal">Contact With Us</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan
                            nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <form name="frmContact" id="frmContact" action="" method="GET" target="#">
                    <div class="row">
                        <div class="form-group col-md-6 mt-4">
                            <div class="border border-muted border-left-0 border-right-0 border-left-0 border-top-0 p-2">
                                <input type="text" placeholder="Name" name="txtName" id="txtName" class="form-control border-0 pl-0 shadow-none">
                            </div>
                            <span id="Nameerror" style="color: red;"></span>
                        </div>
                        <div class="form-group col-md-6 mt-4">
                            <div class="border border-muted border-left-0 border-right-0 border-left-0 border-top-0 p-2">
                                <input type="email" placeholder="Email" name="txtEmail" id="txtEmail" class="form-control border-0 pl-0 shadow-none">
                            </div>
                            <span id="Emailerror" style="color: red;"></span>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-12 mt-4">
                            <div class="border border-muted border-left-0 border-right-0 border-left-0 border-top-0 p-2">
                                <input type="text" placeholder="Subject" name="txtSubject" id="txtSubject" class="form-control border-0 pl-0 shadow-none">
                            </div>
                            <span id="Subjecterror" style="color: red;"></span>
                        </div>
                        <div class="form-group col-12 mt-4">
                            <textarea name="txtMessage" id="txtMessage" class="form-control border-left-0 border-right-0 border-left-0 border-top-0 p-2 rounded-0 shadow-none" rows="5" placeholder="Message"></textarea>
                            <span id="Messageerror" style="color: red;"></span>
                        </div>
                        <div class="form-group text-center col-12 mt-4">
                            <input type="submit" value="SEND MESSAGE" class="btn btn btns9 rounded-pill py-3 px-5">
                        </div>
                    </div>
                </form>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>


<script>
      document.getElementById("frmContact").addEventListener('submit', Contact_validate);
      function Contact_validate(event){
        event.preventDefault();
        var name = document.getElementById("txtName").value;
        var email = document.getElementById("txtEmail").value;
        var subject = document.getElementById("txtSubject").value;
        var message = document.getElementById("txtMessage").value;

        if((name.length <= 0) || (email.length <= 0) || (subject.length <= 0) || (message.length <= 0)){

          if (name.length <= 0){
            document.getElementById("Nameerror").innerHTML = "Please Enter Your Name";
          } else {
            document.getElementById("Nameerror").innerHTML = "";
          }


          if (email.length <= 0) {
            document.getElementById("Emailerror").innerHTML = "Please Enter Your Email";
          } else {
            document.getElementById("Emailerror").innerHTML = "";
          }


          if (subject.length <= 0) {
            document.getElementById("Subjecterror").innerHTML = "Please Enter Your Subject";
          } else {
            document.getElementById("Subjecterror").innerHTML = "";
          }


          if (message.length <= 0) {
            document.getElementById("Messageerror").innerHTML = "Please Enter Your Message";
          } else {
            document.getElementById("Messageerror").innerHTML = "";
          }
        }else{
          document.getElementById("Nameerror").innerHTML = "";
          document.getElementById("Emailerror").innerHTML = "";
          document.getElementById("Subjecterror").innerHTML = "";
          document.getElementById("Messageerror").innerHTML = "";
          alert("success")

          var formdata = new FormData();
          formdata.append('', name)
          formdata.append('', email)
          formdata.append('', subject)
          formdata.append('', message)
          
          fetch('', {
            method: 'POST',
            body: formdata
          })

          .then(function(res) { return res.json(); })
          .then(function(data) {
            if(data.message_type == 'error'){
              alert(data.message);
            }else{
              alert(data.message);
              document.getElementById("frmContact").reset();
            }
          })
          .catch(function(error) {
            console.log('Request Failed'+ error);
          });
        }
      }
  </script>

</body>
</html>