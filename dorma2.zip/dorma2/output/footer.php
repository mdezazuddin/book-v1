  
<!--footer-->
<footer class="bg-black2 foot">
    <div class="container pb-4">
        <div class="row pt-5 pb-5 text-white">
            <div class="col-12 col-md-6 col-lg-4 mt-5 left-reveal">
                <a class="navbar-brand clr-red pt-2 d-flex" href="index.php">
                    <img class="" src="assets/image/logo.png">
                    <span class="h4 text-white align-self-center">Dorma</span>
                </a>
                <p class="mt-2">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Velit ducimus voluptatibus neque illo id repellat quisquam?
                Autem expedita earum quae laborum ipsum ad.</p>
                <div class="d-flex justify-content-start">
                    <a href="#" class="text-decoration-none text-white">
                        <i class="fa fa-pinterest footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-white">
                        <i class="fa fa-twitter footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-white">
                        <i class="fa fa-facebook footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-white">
                        <i class="fa fa-instagram footer-icon"></i>
                    </a>
                    <a href="#" class="text-decoration-none ml-4 text-white">
                        <i class="fa fa-linkedin footer-icon"></i>
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mt-5 left-reveal">
                <h6>PRIVACY & TOS</h6>
                <p class="mt-4 mb-1"><a href="#" class="clr-blue mt-5">Advertiser Agreement</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Acceptable Use Policy</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Privacy Policy</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Technology Privacy</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Developer Agreement</a></p>
            </div>
            <div class="col-12 col-md-6 col-lg-2 mt-5 right-reveal">
                <h6>NAVIGATE</h6>
                <p class="mt-4 mb-1"><a href="#" class="clr-blue mt-5">Advertisers</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Developers</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Resources</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Company</a></p>
                <p class="mb-1"><a href="#" class="clr-blue mt-5">Connect</a></p>
            </div>
            <div class="col-12 col-md-6 col-lg-3 mt-5 right-reveal">
                <h6>CONTACT US</h6>
                <div class="mt-4">
                    <div class="border-0 p-0 d-flex justify-content-start">
                        <p class="mr-3"><i class="fa fa-location-arrow fa-lg clr-blue"></i> </p>
                        <span class="text-decoration-none text-grey1">Mailing Address:xx00 E. Union Ave
                            Suite 1100. Denver, CO 80237 </span>
                    </div>
                    <div class="border-0 mt-2 p-0 d-flex justify-content-start">
                        <p class="mb-2 mr-3"><i class="fa fa-phone fa-lg clr-blue"></i> </p>
                        <a href="tel:+999 90932 627" class="text-decoration-none footer-link-color pt-1"> +999 90932 627</a>
                    </div>
                    <div class="border-0 p-0 d-flex justify-content-start">
                        <p class="mb-2 mr-3"><i class="fa fa-envelope fa-1x clr-blue"></i> </p>
                        <a href="mailto:support@yourdomain.com" class="text-decoration-none footer-link-color pt-1"> support@yourdomain.com</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!--scroll-top-->
<div>
    <a class="scroll-top txt-grad" href="#"> _____ Scroll Top</a>
</div>  
   
