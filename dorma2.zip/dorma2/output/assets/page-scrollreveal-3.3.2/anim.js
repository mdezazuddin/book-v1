 
        window.sr = ScrollReveal();
        sr.reveal('#info-text',{
            origin: 'top',
            distance: '20px',
            duration: 1300,
            reset: true,
            delay    : 200,
            easing: 'cubic-bezier(0.6, 0.2, 0.1, 1)'
        });
        
    