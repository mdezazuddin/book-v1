<?php $page= "home";?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name=”description”>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>xyz</title>

<!-- normalize -->
<link rel="stylesheet" href="assets/css/normalize.min.css">
<!-- fav-icon -->    
<link rel="shortcut icon" href="assets/image/logo.png"> 
<!-- Bootstrap 4.4.1-->
<link rel="stylesheet" href="assets/bootstrap-4.5.2/css/bootstrap.min.css">
<!-- Font-Awesome -->
<link rel="stylesheet" href="assets/font-awesome-4.7.0/css/font-awesome.min.css">
<!-- google-fonts -->    
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<!-- hover-master -->
<link rel="stylesheet" href="assets/Hover-master/css/hover.css">
<!-- Swiper Slider -->
<link rel="stylesheet" href="assets/swiper-master/package/css/swiper.css">
<!-- style.css -->
<link rel="stylesheet" href="assets/css/style.css">

</head>
<body>
    <main>
        <!-- section1 -->
        <section class="section1 bg-sec4">
            <!-- header -->
            <header>
                <?php include("header.php"); ?>
            </header>

            <div class="container py-5 mb-5">
                <div class="row align-items-center py-md-5 mb-5">
                    <div class="col-12 col-lg-6 mt-4 ml-md-auto text-left text-white left-reveal">
                        <h5>Business grow strategy is our mission</h5>
                        <h1 class="mt-4 h2">Take Your Business To The Next Level With Our Agency</h1>
                        <p class="mt-3 p1">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae soluta, dignissimos aut, assumenda dolore totam natus
                        qui cum vel omnis voluptates.</p>
                        <p>
                            <a class="btn btn btns8 rounded-pill px-5 py-3 mt-4" href="#"> Contac Us</a>
                            <a class="btn btn btns8 rounded-pill px-5 py-3 ml-2 mt-4" href="#">Learn More</a> 
                        </p>
                    </div>
                    <div class="col-12 col-lg-6 mt-4 text-md-right right-reveal">
                        
                    </div>
                </div>
            </div>
        </section><br>

        
        <!-- section2 -->
        <section class="section2 mt-5">
            <div class="container pb-5">
                <div class="shadow-sm bg-white mtt1 brd4 p-5">
                    <div class="row text-center">
                        <div class="col-12 mt-3">
                            <h6 class="txt-grad left-reveal">OUR SERVICES</h6>
                            <h2 class="right-reveal">You Succeed</h2>
                            <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut ut felis congue nisl
                                hendrerit
                                commodo.</p>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/1.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum dolor sit amet.</p>
                                    </div>
                                </div>
                                <a class="text-decoration-none icon_foot" href="#">
                                    <i class="fa fa-long-arrow-right hvr-forward"></i>
                                </a>
                            </div>
                        </div>
                    
                        <div class="col-12 col-md-6 col-lg-4 mt-4 right-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/2.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum
                                            dolor sit amet.</p>
                                    </div>
                                    <a class="text-decoration-none icon_foot" href="#">
                                        <i class="fa fa-long-arrow-right hvr-forward"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/3.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum
                                            dolor sit amet.</p>
                                    </div>
                                    <a class="text-decoration-none icon_foot" href="#">
                                        <i class="fa fa-long-arrow-right hvr-forward"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-12 col-md-6 col-lg-4 mt-4 right-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/4.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum
                                            dolor sit amet.</p>
                                    </div>
                                    <a class="text-decoration-none icon_foot" href="#">
                                        <i class="fa fa-long-arrow-right hvr-forward"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/5.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum
                                            dolor sit amet.</p>
                                    </div>
                                    <a class="text-decoration-none icon_foot" href="#">
                                        <i class="fa fa-long-arrow-right hvr-forward"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    
                        <div class="col-12 col-md-6 col-lg-4 mt-4 right-reveal hvr-float-shadow" data-aos="fade-up" data-aos-duration="1000">
                            <div class="shadow-sm brd5 p-2 crd">
                                <div class="media p-3">
                                    <img class="col-3 pl-0" src="assets/image/6.png">
                                    <div class="media-body pl-2">
                                        <a class="text-decoration-none text-red" href="#">
                                            <h5 class="text-body font-weight-bold h6">Investment Advise</h5>
                                        </a>
                                        <p class="text-muted p2 mb-0">Lorem ipsum dolor sit amet, conse ctetur dolor adipisicing elit ipsum
                                            dolor sit amet.</p>
                                    </div>
                                    <a class="text-decoration-none icon_foot" href="#">
                                        <i class="fa fa-long-arrow-right hvr-forward"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section4 -->
        <section class="section4 bg-sec4 py-5">
            <div class="container py-5">
                <div class="row justify-content-center text-white align-items-center">
                    <div class="col-12 col-lg-7">
                        <h6 class="txt-grad left-reveal">CONTACT US NOW IF YOU HAVE ANY QUESTION</h6>
                        <h2 class="left-reveal">Get in Touch with us so Easy.</h2>
                        <p class="mt-4 text-light left-reveal">Lorem ipsum dolor sit amet, adipisicing elit. Ratione provident omnis iusto, veniam
                            libero accusamus esse ab, enim
                            temporibus.</p>
                        <div class="d-md-flex p-3 bg-white rounded-pill mt-4">
                            <div class="border rounded-pill mt-md-0 mt-3 pb-5 form-control d-flex">
                                <i class="fa fa-home fa-lg text-gold mt-2 pt-1 pl-2"></i>
                                <input type="text" class="form-control border-0 shadow-none">
                            </div>
                            <div class="input-group-append ml-sm-3">
                                <button class="btn btn btns8 mx-auto d-block mt-md-0 mt-3 rounded-pill px-5 py-3" type="button">Subscribe</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-5"></div>
                </div>
            </div>
        </section>


        <!-- section5 -->
        <section class="section5 mt-5 pb-4">
            <div class="container ">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">OUR FEATURES</h6>
                        <h2 class="left-reveal right-reveal">Find Your Perfect Teacher</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row mb-3 mt-3">
                    <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg">
                            <a href="#"><img class="w-100" src="assets/image/1.jpg"></a>
                            <div class="p-4">
                                <h5 class="text-body mb-0 font-weight-bold h6">Kesab Barun</h5>
                                <small class="text-muted">Indian Clasic Vocal</small>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg">
                            <a href="#"><img class="w-100" src="assets/image/2.jpg"></a>
                            <div class="p-4">
                                <h5 class="text-body mb-0 font-weight-bold h6">Kesab Barun</h5>
                                <small class="text-muted">Indian Clasic Vocal</small>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                            </div>
                        </div>
                    </div>
                
                    <div class="col-12 col-md-6 col-lg-4 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="shadow-sm rounded-lg">
                            <a href="#"><img class="w-100" src="assets/image/3.jpg"></a>
                            <div class="p-4">
                                <h5 class="text-body mb-0 font-weight-bold h6">Kesab Barun</h5>
                                <small class="text-muted">Indian Clasic Vocal</small>
                                <p class="text-muted  mt-3 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque</p>
                                <a class="btn btn btns9 btn-sm rounded-pill px-4 py-2 mt-4" href="#">View Profile</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section4 -->
        <section class="section4 bg-img1 mt-5">
            <div class="opc1 py-5">
                <div class="container py-5">
                    <div class="row text-center text-white align-items-center">
                        <div class="col-md-8 mx-auto">
                            <h6 class="txt-grad left-reveal">CONTACT US NOW IF YOU HAVE ANY QUESTION</h6>
                            <h2 class="left-reveal">Discover best classes for the best learning</h2>
                            <p class="mt-4 text-light left-reveal">Lorem ipsum dolor sit amet, adipisicing elit. Ratione provident omnis iusto, veniam
                                libero accusamus esse ab, enim
                                temporibus.</p>
                            <a href="#" class="btn btn btns8 mt-4 rounded-pill px-5 py-3" type="button">Get Started</a>
                        </div>
                        <div class="col-12 col-lg-5"></div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section6 -->
        <section class="section6 py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <div class="shadow brd5 p-2 left-reveal">
                            <div class="media p-3">
                                <span class="fa fa-stack fa-lg mr-md-4">
                                    <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                    <i class="fa fa fa-stack-1x text-white">1</i>
                                </span>
                                <div class="media-body pl-2">
                                    <a class="text-decoration-none text-red" href="#">
                                        <h5 class="text-body">Register / Login To Our Platform</h5>
                                    </a>
                                    <p class="text-muted p2 mt-3 mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium modi assumenda beatae nonic.</p>
                                </div>
                            </div>
                        </div>
                        <div class="shadow brd5 p-2 mt-4 right-reveal">
                            <div class="media p-3">
                                <span class="fa fa-stack fa-lg mr-md-4">
                                    <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                    <i class="fa fa fa-stack-1x text-white">2</i>
                                </span>
                                <div class="media-body pl-2">
                                    <a class="text-decoration-none text-red" href="#">
                                        <h5 class="text-body">Enter Your Information Details</h5>
                                    </a>
                                    <p class="text-muted mt-3 p2 mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium modi
                                        assumenda beatae nonic.</p>
                                </div>
                            </div>
                        </div>
                        <div class="shadow brd5 p-2 mt-4 left-reveal">
                            <div class="media p-3">
                                <span class="fa fa-stack fa-lg mr-md-4">
                                    <i class="fa fa-circle fa-stack-2x text-blue"></i>
                                    <i class="fa fa fa-stack-1x text-white">3</i>
                                </span>
                                <div class="media-body pl-2">
                                    <a class="text-decoration-none text-red" href="#">
                                        <h5 class="text-body ">Follow Your App Usage Steps</h5>
                                    </a>
                                    <p class="text-muted mt-3 p2 mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laudantium modi
                                        assumenda beatae nonic.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 mt-5">
                        <img class="w-100 right-reveal" src="assets/image/digital-4.png">
                    </div>
                </div>
            </div>
        </section>
        

        <!-- section7 -->
        <section class="section7 bg-light py-5">
            <div class="container pb-5">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">REPEATED QUESTIONS</h6>
                        <h2 class="right-reveal">Frequently Questions</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-md-6 pl-md-5 mt-5 pt-4">
                        <img class="w-100 left-reveal" src="assets/image/digital-3.png">
                    </div>
                    <div class="col-12 col-md-6 mt-5">
                        <div id="accordion">
                            <div class="card-header py-3 btns9 rounded-pill border-0 mt-3 left-reveal">
                                <a class="card-link text-white d-flex justify-content-between" data-toggle="collapse"
                                    href="#collapseOne">
                                    <span>What are the business advisory company?</span>
                                    <i class="fa fa-chevron-down fa-xs fntt2 mt-1"></i>
                                </a>
                            </div>
                            <div id="collapseOne" class="collapse show" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore omnis quaerat nostrum, pariatur ipsam sunt accusamus
                                    enim necessitatibus est fugiat, assumenda dolorem, deleniti corrupti cupiditate ipsum, dolorum voluptatum esse error?</p>
                                </div>
                            </div>
        
                            <div class="card-header py-3 btns9 rounded-pill border-0 mt-3 right-reveal">
                                <a class="card-link text-white d-flex justify-content-between" data-toggle="collapse"
                                    href="#collapsetwo">
                                    <span>esearch is What Makes an Effective Business Plan?</span>
                                    <i class="fa fa-chevron-down fa-xs fntt2 mt-1"></i>
                                </a>
                            </div>
                            <div id="collapsetwo" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore omnis quaerat nostrum, pariatur ipsam sunt accusamus
                                    enim necessitatibus est fugiat, assumenda dolorem, deleniti corrupti cupiditate ipsum, dolorum voluptatum esse error?</p>
                                </div>
                            </div>
        
                            <div class="card-header py-3 btns9 rounded-pill border-0 mt-3 left-reveal">
                                <a class="card-link text-white d-flex justify-content-between" data-toggle="collapse"
                                    href="#collapsethree">
                                    <span>How to achieving Small Business Success?</span>
                                    <i class="fa fa-chevron-down fa-xs fntt2 mt-1"></i>
                                </a>
                            </div>
                            <div id="collapsethree" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore omnis quaerat nostrum, pariatur ipsam sunt accusamus
                                    enim necessitatibus est fugiat, assumenda dolorem, deleniti corrupti cupiditate ipsum, dolorum voluptatum esse error?</p>
                                </div>
                            </div>
        
                            <div class="card-header py-3 btns9 rounded-pill border-0 mt-3 right-reveal">
                                <a class="card-link text-white d-flex justify-content-between" data-toggle="collapse"
                                    href="#collapsefour">
                                    <span>Why Business Planning is Important?</span>
                                    <i class="fa fa-chevron-down fa-xs fntt2 mt-1"></i>
                                </a>
                            </div>
                            <div id="collapsefour" class="collapse" data-parent="#accordion">
                                <div class="card-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolore omnis quaerat nostrum, pariatur ipsam sunt accusamus
                                    enim necessitatibus est fugiat, assumenda dolorem, deleniti corrupti cupiditate ipsum, dolorum voluptatum esse error?</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section8
        <section class="section8 bg-grey1 py-5">
            <div class="container py-5">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">PRICING PLANS</h6>
                        <h2 class="left-reveal right-reveal">Our Pricing Plans</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row mt-5 align-items-top">
                    <div class="col-12 col-sm-10 col-md-8 m-auto col-lg-4 text-center left-reveal">
                        <div class="bg-gray pb-5 pt-5 pl-4 pr-4 rounded-lg">
                            <h5>BEGGINER</h5>
                            <h1 class="text-blue">Free</h1>
                            <p class="h4">Always</p>
        
                            <p class="mt-4 mb-1">250GB Bandwidth</p>
                            <p class="mb-1">08 Email Account</p>
                            <p class="mb-1">Unlimited Database</p>
                            <p class="mb-1">10GB Free Disk</p>
                            <p class="mb-1">24/7 Support</p>
        
                            <p class="text-center pt-5"><a href="#" class="btn btn px-5 py-3 btns9 rounded-pill">Start</a>
                            </p>
                        </div>
                    </div>
        
                    <div class="col-12 col-sm-10 col-md-8 shadow m-auto col-lg-4 text-center pt-4 pt-lg-0 bottom-reveal">
                        <div class="bg-gray pb-5 pt-5 pl-4 pr-4 rounded-lg">
                            <h5>BUSINESS</h5>
                            <h1 class="text-blue">$24.99</h1>
                            <p class="h4">Per Month</p>
                            
                            <p class="mt-4 mb-1">250GB Bandwidth</p>
                            <p class="mb-1">08 Email Account</p>
                            <p class="mb-1">Unlimited Database</p>
                            <p class="mb-1">10GB Free Disk</p>
                            <p class="mb-1">24/7 Support</p>
                            
                            <p class="text-center pt-5"><a href="#" class="btn btn px-5 py-3 btns9 rounded-pill">Start</a>
                            </p>
                        </div>
                    </div>
        
                    <div class="col-12 col-sm-10 col-md-8 m-auto col-lg-4 text-center pt-4 pt-lg-0 right-reveal">
                        <div class="bg-gray pb-5 pt-5 pl-4 pr-4 rounded-lg">
                            <h5>PROFESSIONAL</h5>
                            <h1 class="text-blue">$84.99</h1>
                            <p class="h4">Per Month</p>
                            
                            <p class="mt-4 mb-1">250GB Bandwidth</p>
                            <p class="mb-1">08 Email Account</p>
                            <p class="mb-1">Unlimited Database</p>
                            <p class="mb-1">10GB Free Disk</p>
                            <p class="mb-1">24/7 Support</p>
                            
                            <p class="text-center pt-5"><a href="#" class="btn btn px-5 py-3 btns9 rounded-pill">Start</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section> -->



        <!-- section2
        <section class="section2 sec2 pb-5 pt-md-5 text-white bg-light" id="section5" data-block-type="call_to_action" data-id="6">
            <div class="container pb-5 mb-5">
                <div class="row d-flex">
                    <div class="col-lg-8 col-7 d-flex mt-5">
                        <h2 class="font-weight-bold display-1 fnnt2 text-grey left-reveal">GALLERY</h2>
                        <span class="mt-4 pt-3 col-md-4 ml2 d-md-block d-none text-dark"><h3>WHAT PEOPLE SAY </h3></span>
                        <span class="col-md-11 mt-1 ml2"><hr class="mt-5 pt-5"></span>
                    </div>
                </div>
                
            <div class="row text-center">
                <div class="col-12">
                    <div class="navbar navbar d-flex justify-content-center">
                        <ul class="navbar nav simplefilter">
                            <li class="nav-item fltr-controls ezaz left-reveal" data-filter="all"><a class="nav-link clr-red pl-md-4 pr-md-4 a13" href="#"><b>ALL</b></a></li>
                            <li class="nav-item fltr-controls ml-lg-4 ml-md-2  ezaz left-reveal" data-filter="1"><a class="nav-link pl-md-4 pr-md-4 text-dark a13" href="#"><b>APARTMENTS</b></a></li>
                            <li class="nav-item fltr-controls ml-lg-4 ml-md-2 ezaz right-reveal" data-filter="2"><a class="nav-link pl-md-4 pr-md-4 text-dark a13" href="#"><b>OFFICES</b></a></li>
                            <li class="nav-item fltr-controls ml-lg-4 ml-md-2 ezaz right-reveal" data-filter="1"><a class="nav-link pl-md-4 pr-md-4 text-dark a13" href="#"><b>CORPORATE DESIGNS</b></a></li>
                        </ul>
                    </div> 
                </div>
            </div>
            
                <div class="row push-down">           
                    <div class="filtr-container pt-4">
                        <div class="">
                            <div class="col-lg-4 col-12 p-2 filtr-item" data-category="2, 5" data-sort="Luminous night">
                                 <!-- normal
                                 <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100"><img class="w-100" src="assets/image/4.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>MODERN LOFT ROOM</h4></a>
                                <p class="text-muted">2013, Commercial, Denmark</p>
                            </div>
                            <div class="col-lg-4 col-12 p-2 filtr-item galleryItem" data-category="1, 4" data-sort="Luminous night">
                                <!-- normal
                                <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100 h-100"><img class="w-100 h-100" src="assets/image/img25.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>ASIA INSPIRED LIVING ROOM</h4></a>
                                <p class="text-muted">2015, Residential Project, Denmark</p>
                            </div>
                            <div class="col-lg-4 col-12 p-2 filtr-item galleryItem" data-category="2, 5" data-sort="Luminous night">
                                <!-- normal
                                <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100 h-100"><img class="w-100 h-100" src="assets/image/img24.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>SUNNY VALLEY HOTEL</h4></a>
                                <p class="text-muted">2013, Custom Project, Spain</p>
                            </div>
                        </div>
                        
                        <div class="">
                            <div class="col-lg-4 col-12 p-2 filtr-item galleryItem" data-category="1, 4" data-sort="Luminous night">
                                <!-- normal
                                <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100 h-100"><img class="w-100 h-100" src="assets/image/img25.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>MCMILLAN’S HOUSE</h4></a>
                                <p class="text-muted">2012, Residential Project, Denmark</p>
                            </div>
                            <div class="col-lg-4 col-12 p-2 filtr-item galleryItem" data-category="2, 5" data-sort="Luminous night">
                                <!-- normal
                                <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100 h-100"><img class="w-100 h-100" src="assets/image/img24.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>MODERN LUXURY HOTEL</h4></a>
                                <p class="text-muted">2011, Custom Project, UK</p>
                            </div>
                            <div class="col-lg-4 col-12 p-2 filtr-item galleryItem" data-category="1, 5" data-sort="Luminous night">
                                <!-- normal
                                <div class="ih-item square mb-4 w-100 h-100 effect13 left_to_right"><a href="#">
                                    <div class="img w-100 h-100"><img class="w-100 h-100" src="assets/image/img25.jpg"></div>
                                    <div class="info w-100">
                                    </div></a></div>
                                <!-- end normal
                                <a class="text-hvr text-decoration-none ltt-spc" href="#"><h4>WEILROUND ENTERTAINMENT</h4></a>
                                <p class="text-muted">2009, Custom Project, Switzerland</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>  -->


        <!-- section6 -->
        <section class="section6 py-5">
            <div class="container">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad left-reveal">OUR TESTIMONIALS</h6>
                        <h2 class="left-reveal right-reveal">What Students Says</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <!-- Swiper -->
                <div class="swiper-container py-4 pl-2 pr-3 mt-3 swiper3">
                    <div class="swiper-wrapper text-center">
                        <div class="swiper-slide">
                            <div class="brd3 p-4">
                                <img class="w-25 rounded-circle" src="assets/image/3.jpg">
                                <div class="mt-4">
                                    <p class="text-muted mt-4 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                        ac cu msan ut, posuere sit Lorem ipsum qu. ac cu msan ut, posuere sit Lorem ipsum qu</p>
                                    <h5 class="text-body font-weight-bold h6 mt-4">Jebin Khan</h5>
                                    <p class="mb-0">Head of Marketing, Company CEO</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="brd3 p-4">
                                <img class="w-25 rounded-circle" src="assets/image/2.jpg">
                                <div class="mt-4">
                                    <p class="text-muted mt-4 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                        ac cu msan ut, posuere sit Lorem ipsum qu. ac cu msan ut, posuere sit Lorem ipsum qu</p>
                                    <h5 class="text-body font-weight-bold h6 mt-4">Sunny Khan</h5>
                                    <p class="mb-0">Head of Marketing, Company CEO</p>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="brd3 p-4">
                                <img class="w-25 rounded-circle" src="assets/image/1.jpg">
                                <div class="mt-4">
                                    <p class="text-muted mt-4 mb-0">Lorem ipsum dolor sit amet, adipiscing elit. Nulla neque quam, maxi ut
                                        ac cu msan ut, posuere sit Lorem ipsum qu. ac cu msan ut, posuere sit Lorem ipsum qu</p>
                                    <h5 class="text-body font-weight-bold h6 mt-4">Ajoy Das</h5>
                                    <p class="mb-0">Head of Marketing, Company CEO</p>
                                </div>
                            </div>
                        </div>
                    </div><br><br><br>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </section>


        <!-- section9 -->
        <section class="section9 mt-5">
            <div class="container ">
                <div class="row text-center">
                    <div class="col-12 mt-3">
                        <h6 class="txt-grad2 left-reveal">Our Creative Team</h6>
                        <h2 class="right-reveal">Our Awesome Team</h2>
                        <p class="col-md-7 mx-auto left-reveal">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed quis accumsan
                            nisi Ut
                            ut felis congue nisl hendrerit
                            commodo.</p>
                    </div>
                </div>
                <div class="row mb-3 mt-3 text-center">
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member1.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Randy Crishen</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Company CEO</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member2.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Monica Ashker</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Web Designer</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member1.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Tollay Ramzomi</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Web Developer</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <div class="con3">
                            <div class="brd2 p-4">
                                <img class="w-100 image3 hvr-sweep-to-top" alt="image" src="assets/image/member2.png">
                                <div class="mt-4">
                                    <h5 class="text-body mb-0 font-weight-bold h6">Jacke Wilson</h5>
                                    <p class="h4 text-gold mb-0 mtt2">___ <span class="h1">.</span> ___</p>
                                    <p class="text-muted mb-0"><small>Marketing Specialist</small></p>
                                </div>
                            </div>
                            <div class="overlay3">
                                <div class="text3">
                                    <div class="d-flex flex-column bg-danger p-3 pt-3 rounded-pill">
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-twitter footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-facebook footer-icon"></i>
                                        </a>
                                        <a href="#" class="text-decoration-none mt-3 text-white">
                                            <i class="fa fa-linkedin footer-icon"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <!-- section7 -->
        <section class="section7 pt-4 mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12 col-md-6 mt-5">
                        <img class="w-100 left-reveal" src="assets/image/6.jpg">
                    </div>
                    <div class="col-12 col-md-6 pl-md-5 mt-5">
                        <h6 class="txt-grad left-reveal">ABOUT US</h6>
                        <h2 class="right-reveal">Learn New Skills to go ahead for Your Career</h2>
                        <p class="left-reveal">Our vision at Nerdclasses is to reimagine and evolve the way teaching and learning that had been happening for decades. By combining quality trainers, engaging content and superior technology we are able to create a superior learning experience for attendees and aid in their outcome improvement, which is unlike any offline experience.<br><br>

NerdClasses empowers anyone who wants to train in the company by providing the required platform. The idea behind the strategy is to create a world class skill learning experience and develop a tech enabled system .</p>
                        <p>
                            <a class="btn btn btns9 rounded-pill px-5 py-3 ml-2 mt-4" href="#">Learn More</a> 
                        </p>
                    </div>
                </div>
            </div>
        </section>


        <!-- section10 -->
        <section class="section10 mt-5">
            <div class="container">
                <div class="row mb-3 mt-3 text-center">
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img src="assets/image/1 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 left-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/2 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/3 (1).png"></a>
                    </div>
        
                    <div class="col-12 col-md-6 col-lg-3 mt-4 right-reveal" data-aos="fade-up" data-aos-duration="1000">
                        <a class="hvr-border-fade px-5 py-3" href="#"><img class="" src="assets/image/4 (1).png"></a>
                    </div>
                </div>
            </div>
        </section>


        <!-- footer -->
        <footer>
            <?php include("footer.php"); ?>
        </footer>
    </main>

<!-- bootstrap 4.4.1 -->
<script src="assets/bootstrap-4.5.2/js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="assets/bootstrap-4.5.2/js/bootstrap.min.js"></script>
<!-- page-scrollreveal-3.3.2 -->
<script src="assets/page-scrollreveal-3.3.2/scrollreveal.min.js"></script>
<!-- Swiper Slider -->
<script src="assets/swiper-master/package/js/swiper.min.js"></script>
<!-- filter-gallary -->     
<script src="assets/filter-gallary/js/jquery.filterizr.min.js"></script>

<!-- javascript.js --> 
<script src="assets/js/common.js"></script>          
<script src="assets/js/index.js"></script>

<script>
    // swiper-master    
    var swiper3 = new Swiper( '.swiper3', {
        spaceBetween: 20,
        loop: true,
        slidesPerView: 1,

        autoplay: {
            delay: 5000,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
            renderBullet: function (index, className) {
                return '<span class="' + className + '">' + (index + 1) + '</span>';
            },
        },

        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
            clickable: true,
        },
        
        // Responsive breakpoints
        breakpoints: {
            // when window width is <= 480px
            480: {
            slidesPerView: 1,
            spaceBetween: 20
            },
            // when window width is <= 640px
            768: {
            slidesPerView: 2,
            spaceBetween: 20
            },
            // when window width is <= 640px
            992: {
            slidesPerView: 2,
            spaceBetween: 20
            }
        },  
    } );


    // filter-gallary    
    $(function() {
      var f = $('.filtr-container').filterizr({ controlsSelector: '.fltr-controls' });
      
    });
</script>

</body>
</html>